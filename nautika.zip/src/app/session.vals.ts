import {CategoryData} from './category/category.component';

export interface sessionVals {
  chosenCat: CategoryData;
  choseCause: string;
  moneyearn: number;
}

