export interface userVals {
  username: string;
  phone: string;
  password: string;
  add1: string;
  add2: string;
  ccnum: string;
  contribs?: number[];
}
